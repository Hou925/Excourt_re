const BASE_URL = 'http://localhost:8000';
const School_URL = 'http://localhost:5000';
module.exports = { BASE_URL, School_URL};
