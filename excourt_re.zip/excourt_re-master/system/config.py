class Config:
    POSTGRES_HOST = "localhost"
    POSTGRES_PORT = 5432
    POSTGRES_USER = "postgres"
    POSTGRES_PASSWORD = "800Compact"
    POSTGRES_DB = "excourt"
    PF_PATH = "profiles"
    QR_PATH = "QR"
    SWAGGER_URL = "/api/docs"
    API_URL = "/static/swagger.yaml"
